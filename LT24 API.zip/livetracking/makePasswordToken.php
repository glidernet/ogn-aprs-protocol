<?php

// PHP make Password Token
// -----------------------

header('Content-Type: text/html; charset=UTF-8');

// get the input
$sessionID = isset($_REQUEST['session']) ? $_REQUEST['session'] : '';
$appSecret = isset($_REQUEST['secret']) ? $_REQUEST['secret'] : '';
$password = isset($_REQUEST['pass']) ? $_REQUEST['pass'] : '';

if ( strlen($sessionID) && strlen($appSecret) && strlen($password) )
{
	// make the token
	$pass = md5(strtolower($password));
	$checkToken = rtrim(strtr(base64_encode(md5( md5($pass . $sessionID )
		. $pass . $appSecret, true)), '+/=', '-_,'), ',');
}
else
{
	$checkToken = '';
}

define('INTO_LT24', array_key_exists('file', $_GET));
$apiFile = substr( __FILE__, strpos( __FILE__, '/api/') + 5);
$file = INTO_LT24 ? 'api?file=' . base64_encode($apiFile) : basename(__FILE__);

echo "<h3>LiveTrack24 API make Password Token</h3>
	<table border=0>
		<form action='" . $file . "'  method='POST'>
			<tr><td>sessionID:</td><td><input type='text' value='$sessionID' name='session'><br></td></tr>
			<tr><td>password:</td><td><input type='text' value='$password' name='pass'><br></td></tr>
			<tr><td>appSecret:</td><td><input type='text' value='$appSecret' name='secret' size='80'><br></td></tr>
			<tr><td></td><td><input type='submit' value='submit' name='submit'></td></tr>
		</form>
	</table>";

echo "<h3>" . ( ( !empty($checkToken) )
		? "The Password Token is: " . $checkToken
		: "all the fields are needed" )
	. ( INTO_LT24
		? '</h3>'
		: "</h3><hr><a href='../index.html'>Home</a>");
