<?php

// PHP check OTP
// -------------

header('Content-Type: text/html; charset=UTF-8');

// get the input
$question = isset($_REQUEST['qwe']) ? $_REQUEST['qwe'] : '';
$appSecret = isset($_REQUEST['secret']) ? $_REQUEST['secret'] : '';

if ( strlen($question) && strlen($appSecret) )
{
	// make the OTP
	$vc = substr( hash_hmac("sha256", $question, $appSecret), 0, 16);
}
else
{
	$vc = '';
}

define('INTO_LT24', array_key_exists('file', $_GET));
$apiFile = substr( __FILE__, strpos( __FILE__, '/api/') + 5);
$file = INTO_LT24 ? 'api?file=' . base64_encode($apiFile) : basename(__FILE__);

echo "<h3>LiveTrack24 API check OTP</h3>
	<table border=0>
		<form action='" . $file . "'  method='POST'>
			<tr><td>qwe:</td><td><input type='text' value='$question' name='qwe'><br></td></tr>
			<tr><td>appSecret:</td><td><input type='text' value='$appSecret' name='secret' size='80'><br></td></tr>
			<tr><td></td><td><input type='submit' value='submit' name='submit'></td></tr>
		</form>
	</table>";
echo "<h3>" . ( ( !empty($vc) )
		? "The OTP is: " . $vc
		: "all the fields are needed" )
	. ( INTO_LT24
		? '</h3>'
		: "</h3><hr><a href='../index.html'>Home</a>");
