<?php
// PHP example implementation
require_once "api.v2.lib.php";
checkLoggedIn();

// testing area of new API op codes

demo('Unknown op code',
	'New op codes born here.',
	'raiseAnError/');

demo('setActiveProfile',
	'Set the active user profile on the server. To deactivate all the profiles use profileID = 0.',
	'setActiveProfile/gzip/1/profileID/1');

demo('getUserProfiles',
	'Get the user profiles with active status.',
	'getUserProfiles/gzip/1');


echo "<hr>";


