<?php
// PHP example implementation
require_once "api.v2.lib.php";
checkLoggedIn();

demo('Login',
'Logs in the given user, returns user info and the user token.',
'6/username/' . myRead('LT24_username') . '/passe/' . myRead('LT24_password'));

demo('setActiveProfile',
	'Set the active user profile on the server. To deactivate all the profiles use profileID = 0.',
	'setActiveProfile/gzip/1/profileID/1');

demo('getUserProfiles',
	'Get the user profiles with active status.',
	'getUserProfiles/gzip/1');

demo('Minimal Info',
	'Get last position info by radius and activity.',
	'30/lat/40.47/lon/23.16/radius/500/ago/86400/countries/gr');

demo('Ping',
	'Gets the server IP, useful for testing.',
	'ping');

demo('User(s) Position Info',
'Returns the latest position info for the given user list. [and/or userIDs list]',
'2/detailLevel/-1/userList/manolis,gioanna/userIDs/7,8,9876/waypointsLimit/1');

demo('Username or userID exists',
'Checks if a username or userID exists.',
'5/username/gust', 'check username exists');

demo('','','5/userID/8','check userID exists');

demo('Get user info',
'Returns user info for the users in given user(s) or users ids.',
'14/userList/GUS,gust,manolis,Rihanna/userIDs/50,40,123,455');

demo('User(s) LiveTracker Button Press Info',
'Returns live info on LiveTracker button presses in the last 12 hours. [and/or userIDs list]',
'13/userList/manolis,gioanna/userIDs/7,8,9876/demo/1');

demo('User(s) Position Info',
'Returns the latest position info for the given user list. [and/or userIDs list]',
'2/detailLevel/-1/userList/manolis,gioanna/userIDs/7,8,9876/waypointsLimit/1');

demo('List takeoffs',
'Returns the waypoints around the given coordinates.',
'3/lat/40.626329/lon/22.948324/radius/50/limit/3');


